// This routine may be called from F90 to get a char[] string
// In this case it is the name of a selected file and the path to it.
// Code uses OPENFILENAME in the case of windows OS, otherwise it has dummy code
  #include <iostream>
//  #include <cstring>
  #include <string>
// #include <stdio>
  #if defined(_WIN32)
// windows code to get file using OPENFILENAME
    #include <windows.h>
    extern "C" 
    {
      int cstr1_(char *cstr,long int arg_len);
    }
    
    int cstr1_(char *cstr, long int arg_len)
    {
      char filename[ MAX_PATH ];
      OPENFILENAME ofn;
        ZeroMemory( &filename, sizeof( filename ) );
        ZeroMemory( &ofn,      sizeof( ofn ) );
        ofn.lStructSize  = sizeof( ofn );
        ofn.hwndOwner    = NULL;  // If you have a window to center over, put its HANDLE here
        ofn.lpstrFilter  = "Input Files\0*.in\0Any File\0*.*\0";
        ofn.lpstrFile    = filename;
        ofn.nMaxFile     = MAX_PATH;
        ofn.lpstrTitle   = "Please select a file";
        ofn.Flags        = OFN_DONTADDTORECENT | OFN_FILEMUSTEXIST;
      long int str_len;
      int k = 0;
// clear the char[] string, based on the array size of the string    
      for (int i=0; i<arg_len; i++) 
        cstr[i]=' ';
      if (GetOpenFileNameA( &ofn ))
      {
//      printf("You chose the file: %s\n",filename);
        for (int i=0; i<arg_len; i++) 
          cstr[i]=filename[i];
//      determine the actual length of the incoming string (if any)    
        while (cstr[k] != '\0')
          ++k;    
// Fill the remainder of the char[] string with blanks    
        for (int i=k; i<arg_len; i++) 
          cstr[i]=' ';
      }
      else
      {
      // All this stuff below is to tell you exactly how you messed up above. 
      // Once you've got that fixed, you can often (not always!) reduce it to a 'user canceled' assumption.
        switch (CommDlgExtendedError())
        {
          case CDERR_DIALOGFAILURE   : std::cout << "CDERR_DIALOGFAILURE\n";   break;
          case CDERR_FINDRESFAILURE  : std::cout << "CDERR_FINDRESFAILURE\n";  break;
          case CDERR_INITIALIZATION  : std::cout << "CDERR_INITIALIZATION\n";  break;
          case CDERR_LOADRESFAILURE  : std::cout << "CDERR_LOADRESFAILURE\n";  break;
          case CDERR_LOADSTRFAILURE  : std::cout << "CDERR_LOADSTRFAILURE\n";  break;
          case CDERR_LOCKRESFAILURE  : std::cout << "CDERR_LOCKRESFAILURE\n";  break;
          case CDERR_MEMALLOCFAILURE : std::cout << "CDERR_MEMALLOCFAILURE\n"; break;
          case CDERR_MEMLOCKFAILURE  : std::cout << "CDERR_MEMLOCKFAILURE\n";  break;
          case CDERR_NOHINSTANCE     : std::cout << "CDERR_NOHINSTANCE\n";     break;
          case CDERR_NOHOOK          : std::cout << "CDERR_NOHOOK\n";          break;
          case CDERR_NOTEMPLATE      : std::cout << "CDERR_NOTEMPLATE\n";      break;
          case CDERR_STRUCTSIZE      : std::cout << "CDERR_STRUCTSIZE\n";      break;
          case FNERR_BUFFERTOOSMALL  : std::cout << "FNERR_BUFFERTOOSMALL\n";  break;
          case FNERR_INVALIDFILENAME : std::cout << "FNERR_INVALIDFILENAME\n"; break;
          case FNERR_SUBCLASSFAILURE : std::cout << "FNERR_SUBCLASSFAILURE\n"; break;
          default                    : std::cout << "File selection canceled\n";
        }
      }
      return 0;
    }
  #else
// not on windows, need dummy code for linux and mac
    extern "C" 
    {
      int cstr1_(char *cstr,long int arg_len);
    }
    
    int cstr1_(char *cstr,long int arg_len)
    {
      unsigned int k = 0;
// determine the actual length of the incoming string (if any)    
      while (cstr[k] != '\0')
        ++k;    
      return 0;
    }
  #endif  
